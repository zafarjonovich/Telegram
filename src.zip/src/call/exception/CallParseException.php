<?php

namespace zafarjonovich\Telegram\call\exception;

class CallParseException extends \Exception
{
}