<?php


namespace zafarjonovich\Telegram\update\objects;


use zafarjonovich\Telegram\update\Objects;
use zafarjonovich\Telegram\update\traits\FileAttributes;

class Document extends Objects
{
    use FileAttributes;
}